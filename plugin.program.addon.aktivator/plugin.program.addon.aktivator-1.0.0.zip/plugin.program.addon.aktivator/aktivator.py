#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc,xbmcgui,os
from sqlite3 import dbapi2

def get_kodi_version():return int(xbmc.getInfoLabel('System.BuildVersion')[:2])

def check_updates():
	xbmc.executebuiltin('XBMC.UpdateLocalAddons()')
	xbmc.executebuiltin('XBMC.UpdateAddonRepos()')

def set_all_enable():
	conn =dbapi2.connect(os.path.join(xbmc.translatePath('special://profile/Database'),'Addons27.db'))
	conn.text_factory = str
	conn.executemany('update installed set enabled=1 WHERE addonID = (?)',((val,) for val in os.listdir(xbmc.translatePath('special://home/addons'))))
	conn.commit()

if get_kodi_version() >= 17:
	xbmc.sleep(500)
	dp = xbmcgui.DialogProgress()
	dp.create('ADDONS AKTIVATOR','Aktiviere alle Addons !','Bitte warten...')
	dp.update(0)

	check_updates()
	xbmc.sleep(500)
	dp.update(30)

	set_all_enable()
	xbmc.sleep(500)
	dp.update(60)

	check_updates()
	xbmc.sleep(500)
	dp.update(100)

	xbmc.sleep(500)
	dp.close()

	xbmcgui.Dialog().ok('ADDONS AKTIVATOR INFO','Fertig !' )
else:xbmcgui.Dialog().ok('ADDONS AKTIVATOR ERROR', 'Die Kodi Version muss mindestens 17 sein !' )