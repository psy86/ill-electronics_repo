from realsocket import gaierror, error, getaddrinfo, SOCK_STREAM
